# Herts Vapes v0.2

Mobile-first GitHub Pages menu for Herts Vapes.

## How to update contacts
Open `script.js` and change:

```js
const whatsappNumber = '447000000000';
const snapchatUsername = 'chazza_manhood';
```

## How to mark a flavour out of stock
In `script.js`, find the flavour and change:

```js
stock: true
```

to:

```js
stock: false
```

The website will automatically show it as out of stock.
